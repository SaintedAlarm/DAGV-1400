using UnityEngine;

public class TransformController : MonoBehaviour
{
    

    void Update()
    {
        // Move the target GameObject up and down
       
        // Rotate the target GameObject
       
        // Scale the target GameObject
    }
}
